import time
mm=8
print('m = ', mm)
n = 100 #the bitsize of p,q
alpha = 400 #the bitsize of e
#betla 表示的是 p q 相同的部分 位置的部分是1/2- betla
betla=0.05 #the bitsize of the same part of of p,q
detla=0.65 # d
nbetla = int(n * betla * 2)
rnbetla = int(n - nbetla)
print('alpha= ',alpha/(2*n) ,' & betla= ',betla,' & detla= ',detla)

# display matrix picture with 0 and X
def matrix_overview(BB, bound):
    for ii in range(BB.dimensions()[0]):
        num = 0
        a = ('%02d ' % ii)
        for jj in range(BB.dimensions()[1]):
            if BB[ii, jj] != 0:
                num = jj
            a += '0' if BB[ii, jj] == 0 else 'X'
            if BB.dimensions()[0] < 60:
                a += ' '
        if abs(BB[ii, num]) >= bound:
            a += '~'
        print(a)


# keyGen function generates parameters.
def keyGen(n,alpha, nbetla,rnbetla):

    while (1):
        if nbetla==0:
            S=0
        else:
            S = ZZ.random_element(2 ^ (nbetla - 1), 2 ^ (nbetla)) #S为pq共享的高位
        pL = next_prime(ZZ.random_element(2 ^ (rnbetla)))
        qL = next_prime(ZZ.random_element(2 ^ (rnbetla)))


        p =S * 2 ^ (rnbetla) + pL
        q = S * 2 ^ (rnbetla) + qL

        if is_prime(p) == False or is_prime(q) == False:
            continue

        ndetla = int(2*n * detla)
        d = next_prime(ZZ.random_element(2 ^ (ndetla - 1), 2 ^ (ndetla)))
        N = p * q

        phi = (p ^ 2 - 1) * (q ^ 2 - 1)
        if (N.nbits() != 2 * n or gcd(d, (p ^ 2 - 1) * (q ^ 2 - 1)) != 1):
            continue

        e = d.inverse_mod(phi)
        k=(e*d-1)/phi
        if (e.nbits() == alpha):
            break

    print(k)
    print("p=",p)
    print("q=",q)
    print("e=", e)
    print("d=", d)



    return N, p, q, e,d,S,k


N, p, q, e, d,S,k= keyGen(n, alpha, nbetla,rnbetla)



#get the Most si
def getV(N,e,S,p,q):
    if S==0:
        return 0
    M=floor(N/(2^(2*n-nbetla)))
    M=floor(sqrt(M*2^nbetla))
    v=M*(2^nbetla)+(floor((N - M ^ 2 * 2 ^ (2 * (rnbetla))) / (M * 2 ^ (rnbetla))) - floor(
        (N - M ^ 2 * 2 ^ (2 * (rnbetla))) / (M * 2 ^ (rnbetla))) % 2 ^ (n - 2 * nbetla + 1)) / 2 ^ (n - 2 * nbetla + 1)
    #print("M*(2^snbetla)=",M*(2^nbetla))
    sum=p+q
    vT=(sum-sum%2^(n-2*nbetla+1))/2^(n-2*nbetla+1)
    if v==vT:
        print("v=vT")
    elif v-1==vT:
        print("v-1==vT")
    else:
        print("v!=vT")
    return vT


start_time = time.time()
v=getV(N,e,S,p,q)


PR.< x, y > = PolynomialRing(ZZ)
XX = int(3 * N ^ (alpha / (2 * n) + detla - 2))
YY = int(2 * N ^ (1 / 2 - 2 * betla))

A = (N + 1) ^ 2 - (v * 2 ^ (n - 2 * nbetla + 1)) ^ 2
a = v * 2 ^ (n - 2 * nbetla + 2)
pol = 1 + A * x - a * x * y - x * y ^ 2

sum=(p+q)%2^(n - 2 * nbetla + 1)
# x-shifts
gg = []
monomials = []
for kk in range(mm + 1):
    for ii in range(mm - kk + 1):
        for jj in range(2):
            xshift = x ^ ii * y ^ jj * pol(x, y) ^ kk * e ^ (mm - kk)
            for monomial in xshift.monomials():
                if monomial not in monomials:
                    monomials.append(monomial)
            gg.append(xshift)

tt = 2 * (1 + 4 * betla - detla) / (1 - 4 * betla)
print("tt=",tt)
# y-shifts (selected by Herrman and May)
ymonomials = []
for jj in range(2,floor(tt*mm) + 1):
    for kk in range(floor(jj/tt),mm+1):
# for kk in range(mm + 1):
#     for jj in range(2, floor(tt*kk) + 2):
        yshift = y ^ jj * pol(x, y) ^ kk * e ^ (mm - kk)
        for monomial in yshift.monomials():
            if monomial not in ymonomials:
                ymonomials.append(monomial)
        gg.append(yshift)

ymonomials.sort()
for monomial in ymonomials:
    if monomial not in monomials:
        monomials.append(monomial)

# construct lattice B
nnm = len(monomials)
print("len(monomials)=",nnm)
for ii in range(nnm):
    print(monomials[ii],end=' ')
print()
nng = len(gg)
BB = Matrix(ZZ, nng, nnm)


for ii in range(nng):
    BB[ii, 0] = gg[ii](0, 0)
    for jj in range(1, nnm):
        if monomials[jj] in gg[ii].monomials():
            BB[ii, jj] = gg[ii].monomial_coefficient(monomials[jj]) * monomials[jj](XX, YY)

matrix_overview(BB,e ^ mm)

CC = BB * (BB.transpose())
det = int(sqrt(CC.det()))
bound = e ^ (mm * nng)
if abs(det) >= bound:
    print("We do not have det < bound. Solutions might not be found.")
    print("Try with highers m and t.")
    diff = (log(det) - log(bound)) / log(2)
else:
    print("det(L) < e^(m*n) (good! If a solution exists < N^delta, it will be found)")


BB = BB.LLL()
print("=== %sLLL seconds ===" % (time.time() - start_time))
print("Ours mm=",mm," detla=",detla," n=",n)

matrix_overview(BB, e ^ mm)

found_polynomials = False

for pol1_idx in range(nng - 1):
    for pol2_idx in range(pol1_idx + 1, nng):
        # for i and j, create the two polynomials
        PR.< w, z > = PolynomialRing(ZZ)
        pol1 = pol2 = 0
        for jj in range(nnm):
            pol1 += monomials[jj] * BB[pol1_idx, jj] / monomials[jj](XX, YY)
            pol2 += monomials[jj] * BB[pol2_idx, jj] / monomials[jj](XX, YY)

        # resultant
        PR.< q > = PolynomialRing(ZZ)
        rr = pol1.resultant(pol2)

        # are these good polynomials?
        if rr.is_zero() or rr.monomials() == [1]:
            continue
        else:
            print("found them, using vectors", pol1_idx, "and", pol2_idx)
            found_polynomials = True
            break
    if found_polynomials:
        break

if not found_polynomials:
    print("no independant vectors could be found. This should very rarely happen...")


rr = rr(q, q)

# solutions
soly = rr.roots()

if len(soly) == 0:
    print("Your prediction (delta) is too small")


soly = soly[0][0]
ss = pol1(q, soly)
solx = ss.roots()[0][0]
print('x = ', solx==k,solx,k)
print('y = ', sum==soly,soly,sum)
print("floor, kk same")
print("=== %all seconds ===" % (time.time() - start_time))









